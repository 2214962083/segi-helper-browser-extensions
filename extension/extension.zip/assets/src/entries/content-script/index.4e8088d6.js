import{d as n,b as e}from"../../../browser-polyfill.87b3f20c.js";import{M as i}from"../../../constants.88769b99.js";(()=>{console.log("content script append script","content-script \u73AF\u5883"),n(i);const t=document.createElement("script");t.innerHTML=`
    // \u6DFB\u52A0 chrome id ${e.runtime.id}
    if (typeof chrome != "object" || !chrome || !chrome.runtime || !chrome.runtime.id) {
      if (!window.chrome) window.chrome = {}
      if (!chrome.runtime) chrome.runtime = {}
      if (!chrome.runtime.id) chrome.runtime = {
        ...chrome.runtime,
        get id() {
          return '${e.runtime.id}'
        }
      }
    }

    // \u5904\u7406 inject-script html \u5185\u5BB9
    // \u628A /assets \u5F00\u5934\u7684\u8D44\u6E90\u66FF\u6362\u6210\u7C7B\u4F3C chrome-extension://xxxxxx/assets \u7684\u8DEF\u5F84
    window.processInjectScriptHtml = html => {
      return html.replace(/"\\/assets\\//g, '"${e.runtime.getURL("assets/")}')
    }
  `,document.documentElement.appendChild(t);const r=document.createElement("script");r.src=e.runtime.getURL("inject-script.js"),document.documentElement.appendChild(r),console.log("content-script init",window)})();
