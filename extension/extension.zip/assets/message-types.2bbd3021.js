var r=(e=>(e.getExtensionResourceUrl="getExtensionResourceUrl",e))(r||{});export{r as W};
