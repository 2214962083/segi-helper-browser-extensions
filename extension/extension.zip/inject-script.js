
(() => {
  const win = top || window

  // 找到本 js 的 script 标签
  const injectScriptEl = win.document.querySelector('#segi-extension-inject-script')

  // 修复开发时 chrome.runtime.id 为空的问题
  if (typeof chrome != "object" || !chrome || !chrome.runtime || !chrome.runtime.id) {
    if (!window.chrome) window.chrome = {}
    if (!chrome.runtime) chrome.runtime = {}
    if (!chrome.runtime.id) chrome.runtime = {
      ...chrome.runtime,
      get id() {
        return injectScriptEl && injectScriptEl.dataset.extensionId
      }
    }
  }

  // 替换资源基础 url
  win.processInjectScriptHtml = html => {
    if (!injectScriptEl) return html
    const baseurl = injectScriptEl.dataset.baseurl
    return html.replace(/"\/assets\//g,`"${baseurl}`)
  }


  const processInjectScriptHtml = win.processInjectScriptHtml || (html => html)
  const htmlParser = new win.DOMParser()
  const htmlDoc = htmlParser.parseFromString(processInjectScriptHtml("<!DOCTYPE html>\r\n<html lang=\"zh-CN\">\r\n  <head>\r\n    <!-- 不要删了这段注释，这是用来识别 inject script html 文件用的 -->\r\n    <!-- html-regexp-inject-script -->\r\n    <meta charset=\"utf-8\" />\r\n    \r\n    <script type=\"module\" crossorigin src=\"/assets/index.html.b77dcf6b.js\"></script>\n    <link rel=\"modulepreload\" href=\"/assets/__uno.a2a3a478.js\">\n    <link rel=\"modulepreload\" href=\"/assets/browser-polyfill.87b3f20c.js\">\n    <link rel=\"modulepreload\" href=\"/assets/constants.cadeba9c.js\">\n    <link rel=\"modulepreload\" href=\"/assets/message-types.2bbd3021.js\">\n    <link rel=\"modulepreload\" href=\"/assets/index.01931ab8.js\">\n    <link rel=\"stylesheet\" href=\"/assets/__uno.67dcc886.css\">\n    <link rel=\"stylesheet\" href=\"/assets/index.71f35cf9.css\">\n  </head>\r\n</html>\r\n"), 'text/html')

  // 复制并插入 script 标签
  const copyScripts = (el, targetEl) => {
    const _scripts = Array.from(el.querySelectorAll('script'))
    const scripts = _scripts.map(_script => {
      const script = win.document.createElement('script')
      script.type = _script.type
      script.src = _script.src
      script.crossorigin = _script.crossorigin
      script.defer = _script.defer
      script.async = _script.async
      script.innerHTML = _script.innerHTML
      return script
    })
    targetEl.append(...scripts)
    return remove = () => scripts.map(scriptEl => scriptEl.remove())
  }

  // 复制并插入 style 标签
  const copyStyles = (el, targetEl) => {
    const _styles = Array.from(el.querySelectorAll('style'))
    const styles = _styles.map(_style => {
      const style = win.document.createElement('style')
      style.type = _style.type
      style.innerHTML = _style.innerHTML
      return style
    })
    targetEl.append(...styles)
    return remove = () => styles.map(styleEl => styleEl.remove())
  }

  // 复制并插入 links 标签
  const copyLinks = (el, targetEl) => {
    const _links = Array.from(el.querySelectorAll('link'))
    const links = _links.map(_link => {
      const link = win.document.createElement('link')
      link.rel = _link.rel
      link.href = _link.href
      link.crossorigin = _link.crossorigin
      link.type = _link.type
      link.media = _link.media
      link.sizes = _link.sizes
      link.integrity = _link.integrity
      link.async = _link.async
      return link
    })
    targetEl.append(...links)
    return remove = () => links.map(linkEl => linkEl.remove())
  }

  copyScripts(htmlDoc.head, win.document.head)

  let isLoadStyle = false
  let removeStyles = null
  let removeLinks = null

  win.segiHelperExtensionRemoveStyle = () => {
    removeStyles && removeStyles()
    removeLinks && removeLinks()
    isLoadStyle = false
  }

  win.segiHelperExtensionLoadStyle = () => {
    if (isLoadStyle) return
    removeStyles = copyStyles(htmlDoc.head, win.document.head)
    removeLinks = copyLinks(htmlDoc.head, win.document.head)
    isLoadStyle = true
  }
})();
        